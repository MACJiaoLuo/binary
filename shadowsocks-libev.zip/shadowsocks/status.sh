#!/system/bin/sh

status_list=(
redsocks
pdnsd
gost
ss-local
obfs-local
);
for i in ${status_list[@]}
do
  echo "$i $(pgrep $i)"
done
iptables -vxn -t nat -L nat_pre --line-number
iptables -vxn -t nat -L nat_lan --line-number
iptables -vxn -t nat -L nat_out --line-number
iptables -vxn -t nat -L shadowsocks --line-number
iptables -vxn -t mangle -L redsocks_pre --line-number
iptables -vxn -t mangle -L mangle_lan --line-number
iptables -vxn -t mangle -L redsocks_out --line-number